package com.example.pollingtest;

import android.os.Parcel;
import android.os.Parcelable;

public class PollRVModal implements Parcelable {
    // creating variables for our different fields.
    private String pollName;
    private String pollDescription;
    private String pollImg;
    private String pollId;

    // creating an empty constructor which is required to use firebase.
    public PollRVModal() {

    }

    // creating getter and setter methods.


    protected PollRVModal(Parcel in) {
        pollName = in.readString();
        pollDescription = in.readString();
        pollImg = in.readString();
        pollId = in.readString();
    }

    public static final Creator<PollRVModal> CREATOR = new Creator<PollRVModal>() {
        @Override
        public PollRVModal createFromParcel(Parcel in) {
            return new PollRVModal(in);
        }

        @Override
        public PollRVModal[] newArray(int size) {
            return new PollRVModal[size];
        }
    };

    public String getPollName() {
        return pollName;
    }

    public void setPollName(String pollName) {
        this.pollName = pollName;
    }

    public String getPollDescription() {
        return pollDescription;
    }

    public void setPollDescription(String pollDescription) {
        this.pollDescription = pollDescription;
    }

    public String getPollImg() {
        return pollImg;
    }

    public void setPollImg(String pollImg) {
        this.pollImg = pollImg;
    }

    public String getPollId() {
        return pollId;
    }

    public void setPollId(String pollId) {
        this.pollId = pollId;
    }

    public PollRVModal(String pollId, String pollName, String pollDescription, String pollImg) {
        this.pollName = pollName;
        this.pollId = pollId;
        this.pollDescription = pollDescription;
        this.pollImg = pollImg;

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(pollName);
        parcel.writeString(pollDescription);
        parcel.writeString(pollImg);
        parcel.writeString(pollId);
    }
}
